package app.earthquake

class RSSParserTest extends groovy.util.GroovyTestCase {
    void testParseRSSString() {
    }
}
