package app.earthquake

class RSSReaderTest extends groovy.util.GroovyTestCase {
    void testGetRssString() {
    }

    void testFetchRSS() {
    }
}
